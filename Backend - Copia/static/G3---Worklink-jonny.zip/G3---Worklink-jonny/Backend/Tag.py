class Tag:
    def __init__(self) -> None:
        self.nome = 'xxxx'